package Book_com.example.Bookdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
