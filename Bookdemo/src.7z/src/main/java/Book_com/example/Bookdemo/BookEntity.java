package Book_com.example.Bookdemo;

public class BookEntity {
	private int id;
	@Override
	public String toString() {
		return "BookEntity [id=" + id + ", title=" + title + ", auther=" + auther + ", publishedYear=" + publishedYear
				+ ", genre=" + genre + "]";
	}
	private String title;
	private String auther;
	private Integer publishedYear;
	private String genre;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuther() {
		return auther;
	}
	public void setAuther(String auther) {
		this.auther = auther;
	}
	public Integer getPublishedYear() {
		return publishedYear;
	}
	public void setPublishedYear(Integer publishedYear) {
		this.publishedYear = publishedYear;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	

}
