package Book_com.example.Bookdemo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class BookService {
	
	
	@Autowired
	private BookRepo bookRepo;
	
	//Get api
	public List<BookEntity> getAllEmployee() {
        return bookRepo.findAll();
    }
	public BookEntity updatePerson(BookEntity person) {
		
		return null;
	}
	 //Add Book
	public String addBook(BookEntity bookEntity) {
		bookRepo.save(bookEntity);
		return "Book added successifully";
	}
//Update Book	
	public String updateEmployee(BookEntity bookEntity) {
		bookRepo.save(bookEntity);
		return "Employee updated Successifully";
	}
}
